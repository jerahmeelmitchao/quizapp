import 'package:flutter/material.dart';
import '../../core/widgets/app_shell.dart';
import '../../core/theme/theme_controller.dart';
import '../upload/upload_page.dart';
import '../recent/recent_generations_page.dart';
import '../flashcards/folder_picker_page.dart';
import '../flashcards/my_notes_page.dart';

class HomePage extends StatelessWidget {
  final ThemeController themeController;

  const HomePage({super.key, required this.themeController});

  @override
  Widget build(BuildContext context) {
    final palette = themeController.palette;

    return Scaffold(
      body: AppShell(
        themeController: themeController,
        child: Padding(
          padding: const EdgeInsets.all(22),
          child: SingleChildScrollView(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const SizedBox(height: 18),
                Text(
                  'QuizGen',
                  style: TextStyle(
                    color: palette.textLight,
                    fontSize: 38,
                    fontWeight: FontWeight.w900,
                  ),
                ),
                const SizedBox(height: 10),
                const Text(
                  'Cute, simple reviewer and quiz generator for your lessons.',
                  style: TextStyle(color: Colors.white70, fontSize: 15),
                ),
                const SizedBox(height: 26),

                TweenAnimationBuilder<double>(
                  duration: const Duration(milliseconds: 350),
                  tween: Tween(begin: 0, end: 1),
                  builder: (context, value, child) {
                    return Opacity(
                      opacity: value,
                      child: Transform.translate(
                        offset: Offset(0, 20 * (1 - value)),
                        child: child,
                      ),
                    );
                  },
                  child: Center(
                    child: ConstrainedBox(
                      constraints: const BoxConstraints(maxWidth: 420),
                      child: Card(
                        child: Padding(
                          padding: const EdgeInsets.all(24),
                          child: Column(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              const SizedBox(height: 12),
                              Container(
                                width: 120,
                                height: 120,
                                decoration: BoxDecoration(
                                  color: palette.secondary.withOpacity(0.12),
                                  borderRadius: BorderRadius.circular(70),
                                ),
                                child: Icon(
                                  Icons.auto_awesome_rounded,
                                  size: 60,
                                  color: palette.secondary,
                                ),
                              ),
                              const SizedBox(height: 22),
                              Text(
                                'Turn your lesson into a smart reviewer',
                                textAlign: TextAlign.center,
                                style: TextStyle(
                                  color: palette.textDark,
                                  fontSize: 24,
                                  fontWeight: FontWeight.w900,
                                ),
                              ),
                              const SizedBox(height: 12),
                              Text(
                                'Upload a PDF, DOCX, or PPTX and generate summary, quiz, and flashcards.',
                                textAlign: TextAlign.center,
                                style: TextStyle(
                                  color: palette.muted,
                                  fontSize: 15,
                                ),
                              ),
                              const SizedBox(height: 24),
                              ElevatedButton(
                                onPressed: () {
                                  Navigator.push(
                                    context,
                                    MaterialPageRoute(
                                      builder: (_) => UploadPage(
                                        themeController: themeController,
                                      ),
                                    ),
                                  );
                                },
                                child: const Text('Start Generating'),
                              ),
                              const SizedBox(height: 8),
                            ],
                          ),
                        ),
                      ),
                    ),
                  ),
                ),

                const SizedBox(height: 26),

                Text(
                  'Quick Actions',
                  style: TextStyle(
                    color: palette.textLight,
                    fontSize: 22,
                    fontWeight: FontWeight.w900,
                  ),
                ),
                const SizedBox(height: 14),

                GridView.count(
                  crossAxisCount: 2,
                  crossAxisSpacing: 12,
                  mainAxisSpacing: 12,
                  physics: const NeverScrollableScrollPhysics(),
                  shrinkWrap: true,
                  children: [
                    _ActionCard(
                      icon: Icons.upload_file_rounded,
                      title: 'Upload',
                      subtitle: 'Generate from lesson files',
                      onTap: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (_) =>
                                UploadPage(themeController: themeController),
                          ),
                        );
                      },
                    ),
                    _ActionCard(
                      icon: Icons.history_rounded,
                      title: 'Recent',
                      subtitle: 'View past generations',
                      onTap: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (_) => RecentGenerationsPage(
                              themeController: themeController,
                            ),
                          ),
                        );
                      },
                    ),
                    _ActionCard(
                      icon: Icons.style_rounded,
                      title: 'Create Flashcards',
                      subtitle: 'Make your own study set',
                      onTap: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (_) => FolderPickerPage(
                              themeController: themeController,
                              mode: FolderPickerMode.createFlashcards,
                            ),
                          ),
                        );
                      },
                    ),
                    _ActionCard(
                      icon: Icons.menu_book_rounded,
                      title: 'Review My Notes',
                      subtitle: 'Study your flashcard sets',
                      onTap: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (_) => MyNotesPage(
                              themeController: themeController,
                            ),
                          ),
                        );
                      },
                    ),
                  ],
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class _ActionCard extends StatelessWidget {
  final IconData icon;
  final String title;
  final String subtitle;
  final VoidCallback? onTap;

  const _ActionCard({
    required this.icon,
    required this.title,
    required this.subtitle,
    this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return TweenAnimationBuilder<double>(
      duration: const Duration(milliseconds: 320),
      tween: Tween(begin: 0, end: 1),
      builder: (context, value, child) {
        return Opacity(
          opacity: value,
          child: Transform.scale(scale: 0.96 + (value * 0.04), child: child),
        );
      },
      child: Card(
        child: InkWell(
          borderRadius: BorderRadius.circular(28),
          onTap: onTap,
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                CircleAvatar(radius: 22, child: Icon(icon)),
                const Spacer(),
                Text(
                  title,
                  style: const TextStyle(
                    fontSize: 17,
                    fontWeight: FontWeight.w800,
                  ),
                ),
                const SizedBox(height: 6),
                Text(
                  subtitle,
                  style: const TextStyle(color: Colors.grey, fontSize: 13),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
