import 'package:flutter/material.dart';

import '../../models/study_folder.dart';
import '../../models/study_set.dart';
import '../../services/study_folder_service.dart';
import '../../services/study_set_service.dart';

class CreateFlashcardPage extends StatefulWidget {
  const CreateFlashcardPage({super.key});

  @override
  State<CreateFlashcardPage> createState() => _CreateFlashcardPageState();
}

class _CreateFlashcardPageState extends State<CreateFlashcardPage> {
  final titleController = TextEditingController();
  final frontController = TextEditingController();
  final backController = TextEditingController();

  List<Flashcard> cards = [];

  // Folder related variables
  List<StudyFolder> folders = [];
  StudyFolder? selectedFolder;

  @override
  void initState() {
    super.initState();
    loadFolders();
  }

  Future<void> loadFolders() async {
    final data = await StudyFolderService.getAll();
    if (!mounted) return;

    setState(() {
      folders = data;
      if (data.isNotEmpty && selectedFolder == null) {
        selectedFolder = data.first;
      }
    });
  }

  void addCard() {
    if (frontController.text.isEmpty || backController.text.isEmpty) return;

    setState(() {
      cards.add(
        Flashcard(
          front: frontController.text,
          back: backController.text,
        ),
      );
      frontController.clear();
      backController.clear();
    });
  }

  Future<void> createFolderDialog() async {
    final controller = TextEditingController();

    await showDialog(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('Create New Folder'),
        content: TextField(
          controller: controller,
          decoration: const InputDecoration(
            hintText: 'Enter folder name',
          ),
          autofocus: true,
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Cancel'),
          ),
          ElevatedButton(
            onPressed: () async {
              final folderName = controller.text.trim();
              if (folderName.isEmpty) return;

              final folder = StudyFolder(
                id: DateTime.now().millisecondsSinceEpoch.toString(),
                name: folderName,
                createdAt: DateTime.now(),
              );

              await StudyFolderService.save(folder);
              Navigator.pop(context);
              await loadFolders();

              // Auto-select the newly created folder
              setState(() {
                selectedFolder = folder;
              });
            },
            child: const Text('Create'),
          ),
        ],
      ),
    );
  }

  Future<void> saveSet() async {
    if (selectedFolder == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Please select or create a folder')),
      );
      return;
    }

    if (titleController.text.trim().isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Please enter a set title')),
      );
      return;
    }

    if (cards.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Please add at least one flashcard')),
      );
      return;
    }

    final set = StudySet(
      id: DateTime.now().millisecondsSinceEpoch.toString(),
      title: titleController.text.trim(),
      folderId: selectedFolder!.id,
      createdAt: DateTime.now(),
      reviewerNotes: [],
      flashcards: cards,
      questions: [],
    );

    await StudySetService.save(set);

    if (mounted) {
      Navigator.pop(context);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Create Flashcards')),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            // Title
            TextField(
              controller: titleController,
              decoration: const InputDecoration(
                labelText: 'Set Title',
                border: OutlineInputBorder(),
              ),
            ),

            const SizedBox(height: 16),

            // Folder Selection
            DropdownButtonFormField<StudyFolder>(
              value: selectedFolder,
              isExpanded: true,
              decoration: const InputDecoration(
                labelText: 'Select Folder',
                border: OutlineInputBorder(),
              ),
              items: folders.map((folder) {
                return DropdownMenuItem(
                  value: folder,
                  child: Text(folder.name),
                );
              }).toList(),
              onChanged: (value) {
                setState(() {
                  selectedFolder = value;
                });
              },
              hint: const Text('Choose a folder'),
            ),

            const SizedBox(height: 8),

            // Create New Folder Button
            OutlinedButton.icon(
              onPressed: createFolderDialog,
              icon: const Icon(Icons.create_new_folder_rounded),
              label: const Text('Create New Folder'),
            ),

            const SizedBox(height: 24),

            // Flashcard Inputs
            TextField(
              controller: frontController,
              decoration: const InputDecoration(
                labelText: 'Front (Question)',
                border: OutlineInputBorder(),
              ),
              maxLines: 2,
            ),

            const SizedBox(height: 12),

            TextField(
              controller: backController,
              decoration: const InputDecoration(
                labelText: 'Back (Answer)',
                border: OutlineInputBorder(),
              ),
              maxLines: 2,
            ),

            const SizedBox(height: 12),

            ElevatedButton.icon(
              onPressed: addCard,
              icon: const Icon(Icons.add),
              label: const Text('Add Card'),
            ),

            const SizedBox(height: 16),

            // List of added cards
            Expanded(
              child: cards.isEmpty
                  ? const Center(
                      child: Text(
                        'No flashcards added yet',
                        style: TextStyle(color: Colors.grey),
                      ),
                    )
                  : ListView.builder(
                      itemCount: cards.length,
                      itemBuilder: (_, i) => Card(
                        margin: const EdgeInsets.symmetric(vertical: 4),
                        child: ListTile(
                          leading: CircleAvatar(
                            child: Text('${i + 1}'),
                          ),
                          title: Text(
                            cards[i].front,
                            maxLines: 2,
                            overflow: TextOverflow.ellipsis,
                          ),
                          subtitle: Text(
                            cards[i].back,
                            maxLines: 2,
                            overflow: TextOverflow.ellipsis,
                          ),
                        ),
                      ),
                    ),
            ),

            const SizedBox(height: 12),

            // Save Button
            ElevatedButton.icon(
              onPressed: saveSet,
              icon: const Icon(Icons.save),
              label: const Text('Save Flashcard Set'),
              style: ElevatedButton.styleFrom(
                minimumSize: const Size.fromHeight(50),
              ),
            ),
          ],
        ),
      ),
    );
  }

  @override
  void dispose() {
    titleController.dispose();
    frontController.dispose();
    backController.dispose();
    super.dispose();
  }
}