import 'dart:async';
import 'package:flutter/material.dart';
import 'app.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();

  FlutterError.onError = (details) {
    FlutterError.dumpErrorToConsole(details);
  };

  ErrorWidget.builder = (FlutterErrorDetails details) {
    return Material(
      color: Colors.white,
      child: Center(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            mainAxisSize: MainAxisSize.min,
            children: const [
              Icon(Icons.error_outline_rounded, size: 56, color: Colors.redAccent),
              SizedBox(height: 12),
              Text(
                'Something went wrong.',
                textAlign: TextAlign.center,
                style: TextStyle(fontSize: 20, fontWeight: FontWeight.w800),
              ),
              SizedBox(height: 8),
              Text(
                'Please restart this screen or try again later.',
                textAlign: TextAlign.center,
              ),
            ],
          ),
        ),
      ),
    );
  };

  runZonedGuarded(() {
    runApp(const QuizGenApp());
  }, (error, stack) {
    debugPrint('Unhandled error: $error');
  });
}
