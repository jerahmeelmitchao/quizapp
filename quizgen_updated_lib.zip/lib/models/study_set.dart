import 'question.dart';

class Flashcard {
  final String front;
  final String back;

  Flashcard({required this.front, required this.back});

  factory Flashcard.fromJson(Map<String, dynamic> json) {
    return Flashcard(
      front: json['front'] ?? '',
      back: json['back'] ?? '',
    );
  }

  Map<String, dynamic> toJson() => {
        'front': front,
        'back': back,
      };
}

class QuizAttempt {
  final int score;
  final int total;
  final bool examMode;
  final int durationSeconds;
  final DateTime createdAt;

  QuizAttempt({
    required this.score,
    required this.total,
    required this.examMode,
    required this.durationSeconds,
    required this.createdAt,
  });

  factory QuizAttempt.fromJson(Map<String, dynamic> json) {
    return QuizAttempt(
      score: json['score'] ?? 0,
      total: json['total'] ?? 0,
      examMode: json['exam_mode'] ?? false,
      durationSeconds: json['duration_seconds'] ?? 0,
      createdAt: DateTime.tryParse(json['created_at'] ?? '') ?? DateTime.now(),
    );
  }

  Map<String, dynamic> toJson() => {
        'score': score,
        'total': total,
        'exam_mode': examMode,
        'duration_seconds': durationSeconds,
        'created_at': createdAt.toIso8601String(),
      };
}

class StudySet {
  final String id;
  final String title;
  final DateTime createdAt;
  final DateTime updatedAt;
  final String folderId;
  final int timesReviewed;
  final DateTime? lastReviewedAt;

  final List<String> reviewerNotes;
  final List<Flashcard> flashcards;
  final List<Question> questions;
  final List<QuizAttempt> quizHistory;

  StudySet({
    required this.id,
    required this.title,
    required this.createdAt,
    required this.updatedAt,
    required this.reviewerNotes,
    required this.flashcards,
    required this.questions,
    required this.folderId,
    required this.quizHistory,
    required this.timesReviewed,
    required this.lastReviewedAt,
  });

  factory StudySet.fromJson(Map<String, dynamic> json) {
    final createdAt = DateTime.tryParse(json['created_at'] ?? '') ?? DateTime.now();
    return StudySet(
      id: json['id'] ?? '',
      title: json['title'] ?? 'Untitled Set',
      createdAt: createdAt,
      updatedAt: DateTime.tryParse(json['updated_at'] ?? '') ?? createdAt,
      folderId: json['folder_id'] ?? '',
      reviewerNotes: List<String>.from(json['reviewer_notes'] ?? []),
      flashcards: (json['flashcards'] as List? ?? [])
          .map((e) => Flashcard.fromJson(Map<String, dynamic>.from(e)))
          .toList(),
      questions: (json['questions'] as List? ?? [])
          .map((e) => Question.fromJson(Map<String, dynamic>.from(e)))
          .toList(),
      quizHistory: (json['quiz_history'] as List? ?? [])
          .map((e) => QuizAttempt.fromJson(Map<String, dynamic>.from(e)))
          .toList(),
      timesReviewed: json['times_reviewed'] ?? 0,
      lastReviewedAt: json['last_reviewed_at'] == null
          ? null
          : DateTime.tryParse(json['last_reviewed_at']),
    );
  }

  Map<String, dynamic> toJson() => {
        'id': id,
        'title': title,
        'created_at': createdAt.toIso8601String(),
        'updated_at': updatedAt.toIso8601String(),
        'folder_id': folderId,
        'reviewer_notes': reviewerNotes,
        'flashcards': flashcards.map((e) => e.toJson()).toList(),
        'questions': questions.map((e) => e.toJson()).toList(),
        'quiz_history': quizHistory.map((e) => e.toJson()).toList(),
        'times_reviewed': timesReviewed,
        'last_reviewed_at': lastReviewedAt?.toIso8601String(),
      };

  StudySet copyWith({
    String? id,
    String? title,
    DateTime? createdAt,
    DateTime? updatedAt,
    String? folderId,
    List<String>? reviewerNotes,
    List<Flashcard>? flashcards,
    List<Question>? questions,
    List<QuizAttempt>? quizHistory,
    int? timesReviewed,
    DateTime? lastReviewedAt,
  }) {
    return StudySet(
      id: id ?? this.id,
      title: title ?? this.title,
      createdAt: createdAt ?? this.createdAt,
      updatedAt: updatedAt ?? this.updatedAt,
      folderId: folderId ?? this.folderId,
      reviewerNotes: reviewerNotes ?? this.reviewerNotes,
      flashcards: flashcards ?? this.flashcards,
      questions: questions ?? this.questions,
      quizHistory: quizHistory ?? this.quizHistory,
      timesReviewed: timesReviewed ?? this.timesReviewed,
      lastReviewedAt: lastReviewedAt ?? this.lastReviewedAt,
    );
  }
}
