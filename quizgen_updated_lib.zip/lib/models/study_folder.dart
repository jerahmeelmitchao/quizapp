class StudyFolder {
  final String id;
  final String name;
  final DateTime createdAt;
  final DateTime updatedAt;
  final int iconCodePoint;
  final int colorValue;
  final int useCount;

  StudyFolder({
    required this.id,
    required this.name,
    required this.createdAt,
    required this.updatedAt,
    required this.iconCodePoint,
    required this.colorValue,
    required this.useCount,
  });

  factory StudyFolder.fromJson(Map<String, dynamic> json) {
    final createdAt = DateTime.tryParse(json['created_at'] ?? '') ?? DateTime.now();
    final updatedAt = DateTime.tryParse(json['updated_at'] ?? '') ?? createdAt;

    return StudyFolder(
      id: json['id'],
      name: json['name'] ?? 'Untitled Folder',
      createdAt: createdAt,
      updatedAt: updatedAt,
      iconCodePoint: json['icon_code_point'] ?? 0xe2c7,
      colorValue: json['color_value'] ?? 0xFF8A6DFF,
      useCount: json['use_count'] ?? 0,
    );
  }

  Map<String, dynamic> toJson() => {
        'id': id,
        'name': name,
        'created_at': createdAt.toIso8601String(),
        'updated_at': updatedAt.toIso8601String(),
        'icon_code_point': iconCodePoint,
        'color_value': colorValue,
        'use_count': useCount,
      };

  StudyFolder copyWith({
    String? id,
    String? name,
    DateTime? createdAt,
    DateTime? updatedAt,
    int? iconCodePoint,
    int? colorValue,
    int? useCount,
  }) {
    return StudyFolder(
      id: id ?? this.id,
      name: name ?? this.name,
      createdAt: createdAt ?? this.createdAt,
      updatedAt: updatedAt ?? this.updatedAt,
      iconCodePoint: iconCodePoint ?? this.iconCodePoint,
      colorValue: colorValue ?? this.colorValue,
      useCount: useCount ?? this.useCount,
    );
  }
}
