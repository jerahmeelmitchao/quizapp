import 'dart:convert';
import 'dart:io';
import 'package:http/http.dart' as http;
import '../models/quiz.dart';

class ApiService {
  static const String baseUrl = 'http://192.168.1.9:8000';

  static Future<Quiz> generateQuiz(File file) async {
    final uri = Uri.parse('$baseUrl/api/generate-quiz');
    final request = http.MultipartRequest('POST', uri)
      ..files.add(await http.MultipartFile.fromPath('file', file.path));

    try {
      final streamedResponse = await request.send().timeout(const Duration(seconds: 25));
      final response = await http.Response.fromStream(streamedResponse);

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        return Quiz.fromJson(data);
      }

      throw HttpException('HTTP ${response.statusCode}: ${response.body}');
    } on SocketException {
      rethrow;
    } on HttpException {
      rethrow;
    } on FormatException {
      rethrow;
    } on Exception {
      rethrow;
    }
  }
}
