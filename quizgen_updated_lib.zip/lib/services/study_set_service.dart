import 'dart:convert';
import 'package:shared_preferences/shared_preferences.dart';
import '../models/study_set.dart';
import 'study_folder_service.dart';

class StudySetService {
  static const _key = 'study_sets';

  static Future<List<StudySet>> getAll() async {
    final prefs = await SharedPreferences.getInstance();
    final raw = prefs.getStringList(_key) ?? [];

    return raw.map((e) => StudySet.fromJson(jsonDecode(e))).toList();
  }

  static Future<void> save(StudySet set) async {
    final prefs = await SharedPreferences.getInstance();
    final current = await getAll();
    current.insert(0, set.copyWith(updatedAt: DateTime.now()));
    await _write(prefs, current);
    await StudyFolderService.touch(set.folderId);
  }

  static Future<void> update(StudySet updatedSet) async {
    final prefs = await SharedPreferences.getInstance();
    final current = await getAll();

    final updated = current.map((e) {
      return e.id == updatedSet.id
          ? updatedSet.copyWith(updatedAt: DateTime.now())
          : e;
    }).toList();

    await _write(prefs, updated);
    await StudyFolderService.touch(updatedSet.folderId);
  }

  static Future<void> delete(String id) async {
    final prefs = await SharedPreferences.getInstance();
    final current = await getAll();
    final updated = current.where((e) => e.id != id).toList();
    await _write(prefs, updated);
  }

  static Future<void> deleteByFolder(String folderId) async {
    final prefs = await SharedPreferences.getInstance();
    final current = await getAll();
    final updated = current.where((e) => e.folderId != folderId).toList();
    await _write(prefs, updated);
  }

  static Future<void> moveToFolder({
    required String setId,
    required String folderId,
  }) async {
    final sets = await getAll();
    final match = sets.where((e) => e.id == setId).cast<StudySet?>().firstWhere((e) => e != null, orElse: () => null);
    if (match == null) return;
    await update(match.copyWith(folderId: folderId, updatedAt: DateTime.now()));
  }

  static Future<void> registerReview(String setId) async {
    final sets = await getAll();
    final match = sets.where((e) => e.id == setId).cast<StudySet?>().firstWhere((e) => e != null, orElse: () => null);
    if (match == null) return;
    await update(match.copyWith(
      timesReviewed: match.timesReviewed + 1,
      lastReviewedAt: DateTime.now(),
    ));
    await StudyFolderService.incrementUse(match.folderId);
  }

  static Future<void> addQuizAttempt({
    required String setId,
    required QuizAttempt attempt,
  }) async {
    final sets = await getAll();
    final match = sets.where((e) => e.id == setId).cast<StudySet?>().firstWhere((e) => e != null, orElse: () => null);
    if (match == null) return;
    final updatedHistory = [attempt, ...match.quizHistory];
    await update(match.copyWith(
      quizHistory: updatedHistory,
      timesReviewed: match.timesReviewed + 1,
      lastReviewedAt: DateTime.now(),
    ));
    await StudyFolderService.incrementUse(match.folderId);
  }

  static Future<void> _write(SharedPreferences prefs, List<StudySet> sets) async {
    await prefs.setStringList(
      _key,
      sets.map((e) => jsonEncode(e.toJson())).toList(),
    );
  }
}
