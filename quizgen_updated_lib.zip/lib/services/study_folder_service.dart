import 'dart:convert';
import 'package:shared_preferences/shared_preferences.dart';
import '../models/study_folder.dart';

class StudyFolderService {
  static const _key = 'study_folders';

  static Future<List<StudyFolder>> getAll() async {
    final prefs = await SharedPreferences.getInstance();
    final raw = prefs.getStringList(_key) ?? [];

    return raw.map((e) => StudyFolder.fromJson(jsonDecode(e))).toList();
  }

  static Future<void> save(StudyFolder folder) async {
    final prefs = await SharedPreferences.getInstance();
    final current = await getAll();
    current.add(folder);
    await _write(prefs, current);
  }

  static Future<void> update(StudyFolder updatedFolder) async {
    final prefs = await SharedPreferences.getInstance();
    final current = await getAll();
    final updated = current.map((e) => e.id == updatedFolder.id ? updatedFolder : e).toList();
    await _write(prefs, updated);
  }

  static Future<void> delete(String folderId) async {
    final prefs = await SharedPreferences.getInstance();
    final current = await getAll();
    final updated = current.where((e) => e.id != folderId).toList();
    await _write(prefs, updated);
  }

  static Future<void> incrementUse(String folderId) async {
    final all = await getAll();
    final folder = all.where((e) => e.id == folderId).cast<StudyFolder?>().firstWhere((e) => e != null, orElse: () => null);
    if (folder == null) return;
    await update(folder.copyWith(
      useCount: folder.useCount + 1,
      updatedAt: DateTime.now(),
    ));
  }

  static Future<void> touch(String folderId) async {
    final all = await getAll();
    final folder = all.where((e) => e.id == folderId).cast<StudyFolder?>().firstWhere((e) => e != null, orElse: () => null);
    if (folder == null) return;
    await update(folder.copyWith(updatedAt: DateTime.now()));
  }

  static Future<void> _write(SharedPreferences prefs, List<StudyFolder> folders) async {
    await prefs.setStringList(
      _key,
      folders.map((e) => jsonEncode(e.toJson())).toList(),
    );
  }
}
