import 'package:flutter/material.dart';
import '../../core/theme/theme_controller.dart';
import '../../core/widgets/app_shell.dart';
import '../../models/study_folder.dart';
import '../../models/study_set.dart';
import '../../services/study_set_service.dart';

class CreateFlashcardPage extends StatefulWidget {
  final ThemeController themeController;
  final StudyFolder folder;
  final StudySet? existingSet;

  const CreateFlashcardPage({
    super.key,
    required this.themeController,
    required this.folder,
    this.existingSet,
  });

  @override
  State<CreateFlashcardPage> createState() => _CreateFlashcardPageState();
}

class _CreateFlashcardPageState extends State<CreateFlashcardPage> {
  final titleController = TextEditingController();
  final frontController = TextEditingController();
  final backController = TextEditingController();
  final frontFocus = FocusNode();

  List<Flashcard> cards = [];
  int? editingIndex;

  bool get isEditMode => widget.existingSet != null;

  @override
  void initState() {
    super.initState();
    if (isEditMode) {
      titleController.text = widget.existingSet!.title;
      cards = List.from(widget.existingSet!.flashcards);
    }
  }

  @override
  void dispose() {
    titleController.dispose();
    frontController.dispose();
    backController.dispose();
    frontFocus.dispose();
    super.dispose();
  }

  void _addOrUpdateCard() {
    final front = frontController.text.trim();
    final back = backController.text.trim();
    if (front.isEmpty || back.isEmpty) return;

    setState(() {
      if (editingIndex != null) {
        cards[editingIndex!] = Flashcard(front: front, back: back);
        editingIndex = null;
      } else {
        cards.add(Flashcard(front: front, back: back));
      }
      frontController.clear();
      backController.clear();
    });

    frontFocus.requestFocus();
  }

  Future<void> _saveSet() async {
    if (titleController.text.trim().isEmpty) {
      _showSnack('Please enter a set title');
      return;
    }
    if (cards.isEmpty) {
      _showSnack('Please add at least one flashcard');
      return;
    }

    final now = DateTime.now();

    if (isEditMode) {
      final updated = widget.existingSet!.copyWith(
        title: titleController.text.trim(),
        folderId: widget.folder.id,
        flashcards: cards,
        updatedAt: now,
      );
      await StudySetService.update(updated);
      if (!mounted) return;
      Navigator.pop(context, updated);
    } else {
      final set = StudySet(
        id: now.millisecondsSinceEpoch.toString(),
        title: titleController.text.trim(),
        folderId: widget.folder.id,
        createdAt: now,
        updatedAt: now,
        reviewerNotes: [],
        flashcards: cards,
        questions: [],
        quizHistory: const [],
        timesReviewed: 0,
        lastReviewedAt: null,
      );
      await StudySetService.save(set);
      if (!mounted) return;
      Navigator.pop(context, set);
    }
  }

  void _showSnack(String msg) {
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(msg)));
  }

  @override
  Widget build(BuildContext context) {
    final palette = widget.themeController.palette;
    final isEditing = editingIndex != null;

    return Scaffold(
      appBar: AppBar(title: Text(isEditMode ? 'Edit Flashcards' : 'Create Flashcards')),
      body: AppShell(
        themeController: widget.themeController,
        child: ListView(
          padding: const EdgeInsets.all(18),
          children: [
            Card(
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: TextField(
                  controller: titleController,
                  style: TextStyle(color: palette.textDark, fontWeight: FontWeight.w800, fontSize: 17),
                  decoration: InputDecoration(
                    hintText: 'Set title',
                    border: InputBorder.none,
                    prefixIcon: Icon(Icons.title_rounded, color: palette.secondary),
                  ),
                ),
              ),
            ),
            const SizedBox(height: 16),
            Card(
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(isEditing ? 'Edit Flashcard' : 'Add Flashcard', style: TextStyle(color: palette.textDark, fontWeight: FontWeight.w800, fontSize: 16)),
                    const SizedBox(height: 12),
                    TextField(
                      controller: frontController,
                      focusNode: frontFocus,
                      maxLines: 2,
                      decoration: const InputDecoration(labelText: 'Front', hintText: 'Question or fact'),
                    ),
                    const SizedBox(height: 10),
                    TextField(
                      controller: backController,
                      maxLines: 2,
                      decoration: const InputDecoration(labelText: 'Back', hintText: 'Answer or explanation'),
                    ),
                    const SizedBox(height: 12),
                    Row(
                      children: [
                        Expanded(
                          child: ElevatedButton.icon(
                            onPressed: _addOrUpdateCard,
                            icon: Icon(isEditing ? Icons.save_rounded : Icons.add_rounded),
                            label: Text(isEditing ? 'Update Card' : 'Add Card'),
                          ),
                        ),
                        if (isEditing) ...[
                          const SizedBox(width: 10),
                          Expanded(
                            child: OutlinedButton(
                              onPressed: () {
                                setState(() {
                                  editingIndex = null;
                                  frontController.clear();
                                  backController.clear();
                                });
                              },
                              child: const Text('Cancel'),
                            ),
                          ),
                        ],
                      ],
                    )
                  ],
                ),
              ),
            ),
            const SizedBox(height: 16),
            Text('Cards (${cards.length})', style: TextStyle(color: palette.textLight, fontSize: 18, fontWeight: FontWeight.w800)),
            const SizedBox(height: 10),
            if (cards.isEmpty)
              Card(
                child: Padding(
                  padding: const EdgeInsets.all(20),
                  child: Text('No cards yet. Add your first flashcard.', style: TextStyle(color: palette.muted)),
                ),
              )
            else
              ...List.generate(cards.length, (index) {
                final card = cards[index];
                return Card(
                  margin: const EdgeInsets.only(bottom: 10),
                  child: ListTile(
                    title: Text(card.front, style: const TextStyle(fontWeight: FontWeight.w800)),
                    subtitle: Text(card.back),
                    trailing: Wrap(
                      spacing: 2,
                      children: [
                        IconButton(
                          icon: const Icon(Icons.edit_rounded),
                          onPressed: () {
                            setState(() {
                              editingIndex = index;
                              frontController.text = card.front;
                              backController.text = card.back;
                            });
                          },
                        ),
                        IconButton(
                          icon: const Icon(Icons.delete_outline_rounded, color: Colors.redAccent),
                          onPressed: () => setState(() => cards.removeAt(index)),
                        ),
                      ],
                    ),
                  ),
                );
              }),
            const SizedBox(height: 12),
            ElevatedButton.icon(
              onPressed: _saveSet,
              icon: const Icon(Icons.save_rounded),
              label: Text(isEditMode ? 'Save Changes' : 'Save Set'),
            ),
          ],
        ),
      ),
    );
  }
}
