import 'package:flutter/material.dart';
import '../../core/theme/theme_controller.dart';
import '../../core/widgets/app_shell.dart';
import '../../models/study_folder.dart';
import '../../models/study_set.dart';
import '../../services/study_folder_service.dart';
import '../../services/study_set_service.dart';
import 'create_flashcard_page.dart';
import 'flashcard_review_page.dart';

class FolderSetsPage extends StatefulWidget {
  final ThemeController themeController;
  final StudyFolder folder;

  const FolderSetsPage({super.key, required this.themeController, required this.folder});

  @override
  State<FolderSetsPage> createState() => _FolderSetsPageState();
}

class _FolderSetsPageState extends State<FolderSetsPage> {
  List<StudySet> sets = [];
  List<StudyFolder> allFolders = [];
  bool isLoading = true;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final all = await StudySetService.getAll();
    final folders = await StudyFolderService.getAll();
    if (!mounted) return;
    setState(() {
      sets = all.where((s) => s.folderId == widget.folder.id).toList();
      allFolders = folders;
      isLoading = false;
    });
  }

  String _formatDate(DateTime? date) {
    if (date == null) return 'Never';
    final d = date.toLocal();
    return '${d.year}-${d.month.toString().padLeft(2, '0')}-${d.day.toString().padLeft(2, '0')}';
  }

  Future<void> _deleteSet(String id) async {
    await StudySetService.delete(id);
    await _load();
  }

  Future<void> _moveSet(StudySet set) async {
    String? selectedFolderId = set.folderId;
    final targetFolders = allFolders.where((f) => f.id != set.folderId).toList();
    if (targetFolders.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Create another folder first.')));
      return;
    }

    final result = await showDialog<String>(
      context: context,
      builder: (_) => StatefulBuilder(
        builder: (context, setModalState) => AlertDialog(
          title: const Text('Move set'),
          content: DropdownButtonFormField<String>(
            value: selectedFolderId == set.folderId ? null : selectedFolderId,
            items: targetFolders
                .map((folder) => DropdownMenuItem(value: folder.id, child: Text(folder.name)))
                .toList(),
            onChanged: (value) => setModalState(() => selectedFolderId = value),
            decoration: const InputDecoration(labelText: 'Choose folder'),
          ),
          actions: [
            TextButton(onPressed: () => Navigator.pop(context), child: const Text('Cancel')),
            ElevatedButton(
              onPressed: selectedFolderId == null ? null : () => Navigator.pop(context, selectedFolderId),
              child: const Text('Move'),
            ),
          ],
        ),
      ),
    );

    if (result != null) {
      await StudySetService.moveToFolder(setId: set.id, folderId: result);
      await _load();
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Set moved successfully.')));
    }
  }

  @override
  Widget build(BuildContext context) {
    final palette = widget.themeController.palette;
    final folderColor = Color(widget.folder.colorValue);

    return Scaffold(
      appBar: AppBar(title: Text(widget.folder.name)),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () async {
          await Navigator.push(
            context,
            MaterialPageRoute(
              builder: (_) => CreateFlashcardPage(themeController: widget.themeController, folder: widget.folder),
            ),
          );
          _load();
        },
        icon: const Icon(Icons.add_rounded),
        label: const Text('New Set'),
      ),
      body: AppShell(
        themeController: widget.themeController,
        child: Padding(
          padding: const EdgeInsets.all(18),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Card(
                child: Padding(
                  padding: const EdgeInsets.all(18),
                  child: Row(
                    children: [
                      Container(
                        width: 52,
                        height: 52,
                        decoration: BoxDecoration(
                          color: folderColor.withOpacity(0.14),
                          borderRadius: BorderRadius.circular(14),
                        ),
                        child: Icon(IconData(widget.folder.iconCodePoint, fontFamily: 'MaterialIcons'), color: folderColor),
                      ),
                      const SizedBox(width: 14),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(widget.folder.name, style: TextStyle(color: palette.textDark, fontWeight: FontWeight.w900, fontSize: 20)),
                            const SizedBox(height: 6),
                            Text('${sets.length} set${sets.length == 1 ? '' : 's'} • ${sets.fold<int>(0, (sum, e) => sum + e.quizHistory.length)} quizzes', style: TextStyle(color: palette.muted)),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              const SizedBox(height: 12),
              Expanded(
                child: isLoading
                    ? const Center(child: CircularProgressIndicator())
                    : sets.isEmpty
                        ? Center(
                            child: Text(
                              'No flashcard sets in this folder.',
                              style: TextStyle(color: palette.textLight.withOpacity(0.75)),
                            ),
                          )
                        : ListView.builder(
                            itemCount: sets.length,
                            itemBuilder: (_, i) {
                              final set = sets[i];
                              return Container(
                                margin: const EdgeInsets.only(bottom: 12),
                                child: Card(
                                  child: InkWell(
                                    borderRadius: BorderRadius.circular(28),
                                    onTap: () async {
                                      await Navigator.push(
                                        context,
                                        MaterialPageRoute(
                                          builder: (_) => FlashcardReviewPage(themeController: widget.themeController, studySet: set),
                                        ),
                                      );
                                      _load();
                                    },
                                    child: Padding(
                                      padding: const EdgeInsets.all(16),
                                      child: Column(
                                        children: [
                                          Row(
                                            children: [
                                              Expanded(
                                                child: Column(
                                                  crossAxisAlignment: CrossAxisAlignment.start,
                                                  children: [
                                                    Text(set.title, style: TextStyle(color: palette.textDark, fontWeight: FontWeight.w800, fontSize: 16)),
                                                    const SizedBox(height: 4),
                                                    Text('${set.flashcards.length} cards • ${set.quizHistory.length} quiz attempts', style: TextStyle(color: palette.muted, fontSize: 13)),
                                                  ],
                                                ),
                                              ),
                                              PopupMenuButton<String>(
                                                onSelected: (value) async {
                                                  if (value == 'edit') {
                                                    await Navigator.push(
                                                      context,
                                                      MaterialPageRoute(
                                                        builder: (_) => CreateFlashcardPage(
                                                          themeController: widget.themeController,
                                                          folder: widget.folder,
                                                          existingSet: set,
                                                        ),
                                                      ),
                                                    );
                                                    _load();
                                                  } else if (value == 'move') {
                                                    _moveSet(set);
                                                  } else if (value == 'delete') {
                                                    final confirm = await showDialog<bool>(
                                                      context: context,
                                                      builder: (_) => AlertDialog(
                                                        title: const Text('Delete set?'),
                                                        content: Text('Delete "${set.title}"? This cannot be undone.'),
                                                        actions: [
                                                          TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('Cancel')),
                                                          ElevatedButton(
                                                            onPressed: () => Navigator.pop(context, true),
                                                            style: ElevatedButton.styleFrom(backgroundColor: Colors.red, foregroundColor: Colors.white),
                                                            child: const Text('Delete'),
                                                          ),
                                                        ],
                                                      ),
                                                    );
                                                    if (confirm == true) {
                                                      _deleteSet(set.id);
                                                    }
                                                  }
                                                },
                                                itemBuilder: (_) => const [
                                                  PopupMenuItem(value: 'edit', child: Text('Edit flashcards')),
                                                  PopupMenuItem(value: 'move', child: Text('Move to another folder')),
                                                  PopupMenuItem(value: 'delete', child: Text('Delete set')),
                                                ],
                                              ),
                                            ],
                                          ),
                                          const SizedBox(height: 12),
                                          Row(
                                            children: [
                                              Expanded(child: _InfoTag(label: 'Reviewed ${set.timesReviewed}x')),
                                              const SizedBox(width: 8),
                                              Expanded(child: _InfoTag(label: 'Last ${_formatDate(set.lastReviewedAt)}')),
                                            ],
                                          ),
                                          if (set.reviewerNotes.isNotEmpty) ...[
                                            const SizedBox(height: 12),
                                            Align(
                                              alignment: Alignment.centerLeft,
                                              child: Text('Reviewer Notes', style: TextStyle(color: palette.textDark, fontWeight: FontWeight.w800)),
                                            ),
                                            const SizedBox(height: 6),
                                            ...set.reviewerNotes.take(2).map((note) => Align(
                                                  alignment: Alignment.centerLeft,
                                                  child: Padding(
                                                    padding: const EdgeInsets.only(bottom: 4),
                                                    child: Text('• $note', style: TextStyle(color: palette.muted)),
                                                  ),
                                                )),
                                          ],
                                          if (set.quizHistory.isNotEmpty) ...[
                                            const SizedBox(height: 12),
                                            Align(
                                              alignment: Alignment.centerLeft,
                                              child: Text('Quiz History', style: TextStyle(color: palette.textDark, fontWeight: FontWeight.w800)),
                                            ),
                                            const SizedBox(height: 6),
                                            ...set.quizHistory.take(3).map((attempt) => Align(
                                                  alignment: Alignment.centerLeft,
                                                  child: Padding(
                                                    padding: const EdgeInsets.only(bottom: 4),
                                                    child: Text(
                                                      '• ${attempt.score}/${attempt.total} ${attempt.examMode ? '(Exam mode)' : '(Practice)'}',
                                                      style: TextStyle(color: palette.muted),
                                                    ),
                                                  ),
                                                )),
                                          ],
                                        ],
                                      ),
                                    ),
                                  ),
                                ),
                              );
                            },
                          ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _InfoTag extends StatelessWidget {
  final String label;

  const _InfoTag({required this.label});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 10),
      decoration: BoxDecoration(color: const Color(0xFFF8F8FC), borderRadius: BorderRadius.circular(14)),
      child: Text(label, textAlign: TextAlign.center, style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w700)),
    );
  }
}
