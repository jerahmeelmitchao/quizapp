import 'package:flutter/material.dart';
import '../../core/theme/theme_controller.dart';
import '../../core/widgets/app_shell.dart';
import '../../models/study_folder.dart';
import '../../services/study_folder_service.dart';
import '../../services/study_set_service.dart';
import 'create_flashcard_page.dart';
import 'folder_sets_page.dart';

enum FolderPickerMode { createFlashcards, reviewNotes }

class FolderPickerPage extends StatefulWidget {
  final ThemeController themeController;
  final FolderPickerMode mode;

  const FolderPickerPage({
    super.key,
    required this.themeController,
    required this.mode,
  });

  @override
  State<FolderPickerPage> createState() => _FolderPickerPageState();
}

class _FolderPickerPageState extends State<FolderPickerPage> {
  static const _folderIcons = [
    Icons.folder_rounded,
    Icons.calculate_rounded,
    Icons.science_rounded,
    Icons.book_rounded,
    Icons.code_rounded,
    Icons.public_rounded,
  ];
  static const _folderColors = [
    Color(0xFF8A6DFF),
    Color(0xFF53D8F3),
    Color(0xFF4CAF50),
    Color(0xFFFF9800),
    Color(0xFFE91E63),
    Color(0xFF607D8B),
  ];

  List<StudyFolder> folders = [];
  Map<String, int> setCounts = {};
  Map<String, int> flashcardCounts = {};
  bool isLoading = true;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final data = await StudyFolderService.getAll();
    final sets = await StudySetService.getAll();
    if (!mounted) return;
    setState(() {
      folders = data;
      setCounts = {
        for (final folder in data)
          folder.id: sets.where((e) => e.folderId == folder.id).length,
      };
      flashcardCounts = {
        for (final folder in data)
          folder.id: sets
              .where((e) => e.folderId == folder.id)
              .fold(0, (sum, e) => sum + e.flashcards.length),
      };
      isLoading = false;
    });
  }

  Future<void> _createFolderDialog({StudyFolder? existing}) async {
    final controller = TextEditingController(text: existing?.name ?? '');
    final palette = widget.themeController.palette;
    IconData selectedIcon = existing == null
        ? _folderIcons.first
        : IconData(existing.iconCodePoint, fontFamily: 'MaterialIcons');
    Color selectedColor = existing == null ? _folderColors.first : Color(existing.colorValue);

    await showDialog(
      context: context,
      builder: (_) => StatefulBuilder(
        builder: (context, setModalState) => AlertDialog(
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(24)),
          title: Text(
            existing == null ? 'New Folder' : 'Edit Folder',
            style: TextStyle(color: palette.textDark, fontWeight: FontWeight.w900),
          ),
          content: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                TextField(
                  controller: controller,
                  autofocus: true,
                  decoration: InputDecoration(
                    hintText: 'Folder name',
                    filled: true,
                    fillColor: palette.border.withOpacity(0.3),
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(14),
                      borderSide: BorderSide.none,
                    ),
                  ),
                ),
                const SizedBox(height: 16),
                const Text('Icon'),
                const SizedBox(height: 10),
                Wrap(
                  spacing: 8,
                  runSpacing: 8,
                  children: _folderIcons.map((icon) {
                    final active = selectedIcon.codePoint == icon.codePoint;
                    return ChoiceChip(
                      selected: active,
                      label: Icon(icon),
                      onSelected: (_) => setModalState(() => selectedIcon = icon),
                    );
                  }).toList(),
                ),
                const SizedBox(height: 16),
                const Text('Color'),
                const SizedBox(height: 10),
                Wrap(
                  spacing: 8,
                  runSpacing: 8,
                  children: _folderColors.map((color) {
                    final active = selectedColor.value == color.value;
                    return GestureDetector(
                      onTap: () => setModalState(() => selectedColor = color),
                      child: Container(
                        width: 34,
                        height: 34,
                        decoration: BoxDecoration(
                          color: color,
                          shape: BoxShape.circle,
                          border: active ? Border.all(color: Colors.black, width: 3) : null,
                        ),
                      ),
                    );
                  }).toList(),
                ),
              ],
            ),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: const Text('Cancel'),
            ),
            ElevatedButton(
              style: ElevatedButton.styleFrom(
                backgroundColor: palette.secondary,
                foregroundColor: Colors.white,
                minimumSize: const Size(90, 42),
              ),
              onPressed: () async {
                final name = controller.text.trim();
                if (name.isEmpty) return;
                final now = DateTime.now();
                final folder = (existing ?? StudyFolder(
                  id: now.millisecondsSinceEpoch.toString(),
                  name: name,
                  createdAt: now,
                  updatedAt: now,
                  iconCodePoint: selectedIcon.codePoint,
                  colorValue: selectedColor.value,
                  useCount: 0,
                )).copyWith(
                  name: name,
                  updatedAt: now,
                  iconCodePoint: selectedIcon.codePoint,
                  colorValue: selectedColor.value,
                );

                if (existing == null) {
                  await StudyFolderService.save(folder);
                } else {
                  await StudyFolderService.update(folder);
                }

                if (!mounted) return;
                Navigator.pop(context);
                await _load();
                if (existing == null && mounted) {
                  _navigateToFolder(folder);
                }
              },
              child: Text(existing == null ? 'Create' : 'Save'),
            ),
          ],
        ),
      ),
    );
  }

  Future<void> _deleteFolder(StudyFolder folder) async {
    await StudySetService.deleteByFolder(folder.id);
    await StudyFolderService.delete(folder.id);
    await _load();
  }

  void _navigateToFolder(StudyFolder folder) {
    if (widget.mode == FolderPickerMode.createFlashcards) {
      Navigator.push(
        context,
        MaterialPageRoute(
          builder: (_) => CreateFlashcardPage(
            themeController: widget.themeController,
            folder: folder,
          ),
        ),
      ).then((_) => _load());
    } else {
      Navigator.push(
        context,
        MaterialPageRoute(
          builder: (_) => FolderSetsPage(
            themeController: widget.themeController,
            folder: folder,
          ),
        ),
      ).then((_) => _load());
    }
  }

  @override
  Widget build(BuildContext context) {
    final palette = widget.themeController.palette;
    final isCreate = widget.mode == FolderPickerMode.createFlashcards;
    final title = isCreate ? 'Choose a Folder' : 'Folders';

    return Scaffold(
      appBar: AppBar(title: Text(title)),
      body: AppShell(
        themeController: widget.themeController,
        child: Padding(
          padding: const EdgeInsets.all(20),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                isCreate ? 'Where should your flashcards go?' : 'Open a folder to review your notes',
                style: TextStyle(color: palette.textLight, fontSize: 18, fontWeight: FontWeight.w700),
              ),
              const SizedBox(height: 18),
              GestureDetector(
                onTap: () => _createFolderDialog(),
                child: Container(
                  width: double.infinity,
                  padding: const EdgeInsets.symmetric(vertical: 18, horizontal: 20),
                  decoration: BoxDecoration(
                    color: palette.secondary.withOpacity(0.18),
                    borderRadius: BorderRadius.circular(20),
                    border: Border.all(color: palette.secondary.withOpacity(0.4), width: 1.5),
                  ),
                  child: Row(
                    children: [
                      Container(
                        width: 44,
                        height: 44,
                        decoration: BoxDecoration(
                          color: palette.secondary.withOpacity(0.2),
                          borderRadius: BorderRadius.circular(12),
                        ),
                        child: Icon(Icons.create_new_folder_rounded, color: palette.secondary),
                      ),
                      const SizedBox(width: 16),
                      Text(
                        'Create New Folder',
                        style: TextStyle(color: palette.textLight, fontSize: 16, fontWeight: FontWeight.w800),
                      ),
                    ],
                  ),
                ),
              ),
              const SizedBox(height: 20),
              if (isLoading)
                const Expanded(child: Center(child: CircularProgressIndicator()))
              else if (folders.isEmpty)
                Expanded(
                  child: Center(
                    child: Text(
                      'No folders yet.\nCreate one to get started!',
                      textAlign: TextAlign.center,
                      style: TextStyle(color: palette.textLight.withOpacity(0.55), fontSize: 15),
                    ),
                  ),
                )
              else
                Expanded(
                  child: ListView.builder(
                    itemCount: folders.length,
                    itemBuilder: (_, i) {
                      final folder = folders[i];
                      final folderColor = Color(folder.colorValue);
                      return Container(
                        margin: const EdgeInsets.only(bottom: 10),
                        child: Card(
                          child: InkWell(
                            borderRadius: BorderRadius.circular(28),
                            onTap: () => _navigateToFolder(folder),
                            child: Padding(
                              padding: const EdgeInsets.symmetric(vertical: 14, horizontal: 16),
                              child: Row(
                                children: [
                                  Container(
                                    width: 44,
                                    height: 44,
                                    decoration: BoxDecoration(
                                      color: folderColor.withOpacity(0.12),
                                      borderRadius: BorderRadius.circular(12),
                                    ),
                                    child: Icon(
                                      IconData(folder.iconCodePoint, fontFamily: 'MaterialIcons'),
                                      color: folderColor,
                                    ),
                                  ),
                                  const SizedBox(width: 14),
                                  Expanded(
                                    child: Column(
                                      crossAxisAlignment: CrossAxisAlignment.start,
                                      children: [
                                        Text(
                                          folder.name,
                                          style: TextStyle(color: palette.textDark, fontSize: 16, fontWeight: FontWeight.w800),
                                        ),
                                        const SizedBox(height: 4),
                                        Text(
                                          '${setCounts[folder.id] ?? 0} sets • ${flashcardCounts[folder.id] ?? 0} cards',
                                          style: TextStyle(color: palette.muted, fontSize: 13),
                                        ),
                                      ],
                                    ),
                                  ),
                                  PopupMenuButton<String>(
                                    onSelected: (value) async {
                                      if (value == 'edit') {
                                        _createFolderDialog(existing: folder);
                                      } else if (value == 'delete') {
                                        final confirm = await showDialog<bool>(
                                          context: context,
                                          builder: (_) => AlertDialog(
                                            title: const Text('Delete folder?'),
                                            content: Text('Delete "${folder.name}" and all sets inside it?'),
                                            actions: [
                                              TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('Cancel')),
                                              ElevatedButton(
                                                onPressed: () => Navigator.pop(context, true),
                                                style: ElevatedButton.styleFrom(backgroundColor: Colors.red, foregroundColor: Colors.white),
                                                child: const Text('Delete'),
                                              ),
                                            ],
                                          ),
                                        );
                                        if (confirm == true) {
                                          _deleteFolder(folder);
                                        }
                                      }
                                    },
                                    itemBuilder: (_) => const [
                                      PopupMenuItem(value: 'edit', child: Text('Rename / customize')),
                                      PopupMenuItem(value: 'delete', child: Text('Delete folder')),
                                    ],
                                  ),
                                ],
                              ),
                            ),
                          ),
                        ),
                      );
                    },
                  ),
                ),
            ],
          ),
        ),
      ),
    );
  }
}
