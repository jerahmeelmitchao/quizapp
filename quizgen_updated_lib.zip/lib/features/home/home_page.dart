import 'package:flutter/material.dart';
import '../../core/widgets/app_shell.dart';
import '../../core/theme/theme_controller.dart';
import '../../models/study_folder.dart';
import '../../models/study_set.dart';
import '../../services/study_folder_service.dart';
import '../../services/study_set_service.dart';
import '../about/about_page.dart';
import '../upload/upload_page.dart';
import '../recent/recent_generations_page.dart';
import '../flashcards/folder_picker_page.dart';
import '../flashcards/folder_sets_page.dart';

enum FolderSortOption { recent, mostUsed, alphabet }

class HomePage extends StatefulWidget {
  final ThemeController themeController;

  const HomePage({super.key, required this.themeController});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  List<StudyFolder> folders = [];
  List<StudySet> sets = [];
  bool isLoading = true;
  FolderSortOption sortOption = FolderSortOption.recent;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final loadedFolders = await StudyFolderService.getAll();
    final loadedSets = await StudySetService.getAll();
    if (!mounted) return;
    setState(() {
      folders = loadedFolders;
      sets = loadedSets;
      isLoading = false;
    });
  }

  List<StudyFolder> get sortedFolders {
    final copy = [...folders];
    switch (sortOption) {
      case FolderSortOption.recent:
        copy.sort((a, b) => b.updatedAt.compareTo(a.updatedAt));
        break;
      case FolderSortOption.mostUsed:
        copy.sort((a, b) => b.useCount.compareTo(a.useCount));
        break;
      case FolderSortOption.alphabet:
        copy.sort((a, b) => a.name.toLowerCase().compareTo(b.name.toLowerCase()));
        break;
    }
    return copy;
  }

  int _flashcardCount(String folderId) =>
      sets.where((e) => e.folderId == folderId).fold(0, (sum, e) => sum + e.flashcards.length);

  int _quizCount(String folderId) =>
      sets.where((e) => e.folderId == folderId).fold(0, (sum, e) => sum + e.quizHistory.length);

  int _setCount(String folderId) => sets.where((e) => e.folderId == folderId).length;

  String _formatDate(DateTime value) {
    final date = value.toLocal();
    return '${date.year}-${date.month.toString().padLeft(2, '0')}-${date.day.toString().padLeft(2, '0')}';
  }

  @override
  Widget build(BuildContext context) {
    final palette = widget.themeController.palette;

    return Scaffold(
      body: AppShell(
        themeController: widget.themeController,
        child: RefreshIndicator(
          onRefresh: _load,
          child: ListView(
            padding: const EdgeInsets.all(20),
            children: [
              const SizedBox(height: 10),
              Row(
                children: [
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          'QuizGen',
                          style: TextStyle(
                            color: palette.textLight,
                            fontSize: 36,
                            fontWeight: FontWeight.w900,
                          ),
                        ),
                        const SizedBox(height: 6),
                        Text(
                          'Folders first. Study sets, notes, and quiz history in one place.',
                          style: TextStyle(color: palette.textLight.withOpacity(0.75)),
                        ),
                      ],
                    ),
                  ),
                  IconButton(
                    onPressed: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (_) => AboutPage(themeController: widget.themeController),
                        ),
                      );
                    },
                    icon: const Icon(Icons.info_outline_rounded, color: Colors.white),
                  ),
                ],
              ),
              const SizedBox(height: 18),
              Card(
                child: Padding(
                  padding: const EdgeInsets.all(18),
                  child: Column(
                    children: [
                      Row(
                        children: [
                          Expanded(
                            child: _StatTile(label: 'Folders', value: '${folders.length}', icon: Icons.folder_rounded),
                          ),
                          const SizedBox(width: 10),
                          Expanded(
                            child: _StatTile(label: 'Sets', value: '${sets.length}', icon: Icons.style_rounded),
                          ),
                        ],
                      ),
                      const SizedBox(height: 10),
                      Row(
                        children: [
                          Expanded(
                            child: _StatTile(
                              label: 'Flashcards',
                              value: '${sets.fold<int>(0, (sum, e) => sum + e.flashcards.length)}',
                              icon: Icons.auto_stories_rounded,
                            ),
                          ),
                          const SizedBox(width: 10),
                          Expanded(
                            child: _StatTile(
                              label: 'Quizzes',
                              value: '${sets.fold<int>(0, (sum, e) => sum + e.quizHistory.length)}',
                              icon: Icons.quiz_rounded,
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              ),
              const SizedBox(height: 18),
              Text(
                'Quick Actions',
                style: TextStyle(color: palette.textLight, fontSize: 22, fontWeight: FontWeight.w900),
              ),
              const SizedBox(height: 12),
              GridView.count(
                crossAxisCount: 2,
                crossAxisSpacing: 12,
                mainAxisSpacing: 12,
                physics: const NeverScrollableScrollPhysics(),
                shrinkWrap: true,
                childAspectRatio: 1.05,
                children: [
                  _ActionCard(
                    icon: Icons.upload_file_rounded,
                    title: 'Generate',
                    subtitle: 'Upload lesson file',
                    onTap: () async {
                      await Navigator.push(
                        context,
                        MaterialPageRoute(builder: (_) => UploadPage(themeController: widget.themeController)),
                      );
                      _load();
                    },
                  ),
                  _ActionCard(
                    icon: Icons.create_new_folder_rounded,
                    title: 'Create Cards',
                    subtitle: 'Choose a folder',
                    onTap: () async {
                      await Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (_) => FolderPickerPage(
                            themeController: widget.themeController,
                            mode: FolderPickerMode.createFlashcards,
                          ),
                        ),
                      );
                      _load();
                    },
                  ),
                  _ActionCard(
                    icon: Icons.history_rounded,
                    title: 'Recent',
                    subtitle: 'Past generations',
                    onTap: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (_) => RecentGenerationsPage(themeController: widget.themeController),
                        ),
                      );
                    },
                  ),
                  _ActionCard(
                    icon: Icons.menu_book_rounded,
                    title: 'Review Notes',
                    subtitle: 'Open folders',
                    onTap: () async {
                      await Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (_) => FolderPickerPage(
                            themeController: widget.themeController,
                            mode: FolderPickerMode.reviewNotes,
                          ),
                        ),
                      );
                      _load();
                    },
                  ),
                ],
              ),
              const SizedBox(height: 22),
              Row(
                children: [
                  Expanded(
                    child: Text(
                      'Folders',
                      style: TextStyle(color: palette.textLight, fontSize: 22, fontWeight: FontWeight.w900),
                    ),
                  ),
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 12),
                    decoration: BoxDecoration(
                      color: Colors.white.withOpacity(0.12),
                      borderRadius: BorderRadius.circular(18),
                    ),
                    child: DropdownButtonHideUnderline(
                      child: DropdownButton<FolderSortOption>(
                        value: sortOption,
                        dropdownColor: palette.card,
                        onChanged: (value) {
                          if (value == null) return;
                          setState(() => sortOption = value);
                        },
                        items: const [
                          DropdownMenuItem(value: FolderSortOption.recent, child: Text('Recent')),
                          DropdownMenuItem(value: FolderSortOption.mostUsed, child: Text('Most used')),
                          DropdownMenuItem(value: FolderSortOption.alphabet, child: Text('Alphabet')),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 12),
              if (isLoading)
                const Padding(
                  padding: EdgeInsets.only(top: 50),
                  child: Center(child: CircularProgressIndicator()),
                )
              else if (folders.isEmpty)
                Card(
                  child: Padding(
                    padding: const EdgeInsets.all(24),
                    child: Column(
                      children: [
                        Icon(Icons.folder_open_rounded, size: 64, color: palette.secondary),
                        const SizedBox(height: 12),
                        Text(
                          'No folders yet',
                          style: TextStyle(color: palette.textDark, fontSize: 22, fontWeight: FontWeight.w900),
                        ),
                        const SizedBox(height: 8),
                        Text(
                          'Create your first folder from Create Cards and start organizing your study sets.',
                          textAlign: TextAlign.center,
                          style: TextStyle(color: palette.muted),
                        ),
                      ],
                    ),
                  ),
                )
              else
                ...sortedFolders.map((folder) {
                  final folderColor = Color(folder.colorValue);
                  return Container(
                    margin: const EdgeInsets.only(bottom: 12),
                    child: Card(
                      child: InkWell(
                        borderRadius: BorderRadius.circular(28),
                        onTap: () async {
                          await Navigator.push(
                            context,
                            MaterialPageRoute(
                              builder: (_) => FolderSetsPage(
                                themeController: widget.themeController,
                                folder: folder,
                              ),
                            ),
                          );
                          _load();
                        },
                        child: Padding(
                          padding: const EdgeInsets.all(18),
                          child: Column(
                            children: [
                              Row(
                                children: [
                                  Container(
                                    width: 52,
                                    height: 52,
                                    decoration: BoxDecoration(
                                      color: folderColor.withOpacity(0.14),
                                      borderRadius: BorderRadius.circular(14),
                                    ),
                                    child: Icon(IconData(folder.iconCodePoint, fontFamily: 'MaterialIcons'), color: folderColor),
                                  ),
                                  const SizedBox(width: 14),
                                  Expanded(
                                    child: Column(
                                      crossAxisAlignment: CrossAxisAlignment.start,
                                      children: [
                                        Text(
                                          folder.name,
                                          style: TextStyle(color: palette.textDark, fontSize: 17, fontWeight: FontWeight.w800),
                                        ),
                                        const SizedBox(height: 4),
                                        Text(
                                          'Last updated ${_formatDate(folder.updatedAt)}',
                                          style: TextStyle(color: palette.muted, fontSize: 13),
                                        ),
                                      ],
                                    ),
                                  ),
                                  Icon(Icons.chevron_right_rounded, color: palette.muted),
                                ],
                              ),
                              const SizedBox(height: 14),
                              Row(
                                children: [
                                  Expanded(child: _FolderInfoChip(label: '${_setCount(folder.id)} sets')),
                                  const SizedBox(width: 8),
                                  Expanded(child: _FolderInfoChip(label: '${_flashcardCount(folder.id)} flashcards')),
                                  const SizedBox(width: 8),
                                  Expanded(child: _FolderInfoChip(label: '${_quizCount(folder.id)} quizzes')),
                                ],
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                  );
                }),
            ],
          ),
        ),
      ),
    );
  }
}

class _StatTile extends StatelessWidget {
  final String label;
  final String value;
  final IconData icon;

  const _StatTile({required this.label, required this.value, required this.icon});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: const Color(0xFFF7F7FB),
        borderRadius: BorderRadius.circular(20),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Icon(icon),
          const SizedBox(height: 12),
          Text(value, style: const TextStyle(fontSize: 24, fontWeight: FontWeight.w900)),
          const SizedBox(height: 2),
          Text(label, style: const TextStyle(color: Colors.grey)),
        ],
      ),
    );
  }
}

class _FolderInfoChip extends StatelessWidget {
  final String label;

  const _FolderInfoChip({required this.label});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 10),
      decoration: BoxDecoration(
        color: const Color(0xFFF8F8FC),
        borderRadius: BorderRadius.circular(14),
      ),
      child: Text(
        label,
        textAlign: TextAlign.center,
        style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w700),
      ),
    );
  }
}

class _ActionCard extends StatelessWidget {
  final IconData icon;
  final String title;
  final String subtitle;
  final VoidCallback onTap;

  const _ActionCard({required this.icon, required this.title, required this.subtitle, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return Card(
      child: InkWell(
        borderRadius: BorderRadius.circular(28),
        onTap: onTap,
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              CircleAvatar(radius: 22, child: Icon(icon)),
              const Spacer(),
              Text(title, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w800)),
              const SizedBox(height: 6),
              Text(subtitle, style: const TextStyle(color: Colors.grey, fontSize: 12)),
            ],
          ),
        ),
      ),
    );
  }
}
